SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `accomplishment_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_number` varchar(30) NOT NULL,
  `report_type` enum('quarterly','semi_annual','annual','terminal') NOT NULL,
  `period_quarter` enum('Q1','Q2','Q3','Q4') DEFAULT NULL,
  `period_year` year(4) DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `summary` text DEFAULT NULL,
  `submitted_by` int(11) NOT NULL,
  `date_submitted` date DEFAULT NULL,
  `status` enum('draft','submitted','under_review','approved','returned') NOT NULL DEFAULT 'draft',
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `report_number` (`report_number`),
  KEY `fk_ar_project` (`project_id`),
  KEY `fk_ar_submitter` (`submitted_by`),
  CONSTRAINT `fk_ar_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ar_submitter` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `accomplishment_reports` VALUES ('1','AR-2026-0001','quarterly','Q1','2026','1','Q1 Accomplishment Report - Organic Farming','First quarter activities completed. 3 training sessions conducted with 45 participants.','3','2026-04-05','approved',NULL,NULL,NULL,NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `accomplishment_reports` VALUES ('2','AR-2026-0002','quarterly','Q1','2026','3','Q1 Accomplishment Report - Digital Literacy','Computer basics workshop completed. 30 seniors trained.','4','2026-04-03','approved',NULL,NULL,NULL,NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `accomplishment_reports` VALUES ('3','AR-2025-0003','terminal',NULL,'2025','5','Terminal Report - Health and Nutrition','Project completed successfully. 200 community members reached.','3','2026-01-15','approved',NULL,NULL,NULL,NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11');
CREATE TABLE `activity_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `assignment_type` enum('leader','member') NOT NULL DEFAULT 'member',
  `assigned_by` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `act_faculty` (`activity_id`,`faculty_id`),
  KEY `fk_acta_act` (`activity_id`),
  KEY `fk_acta_faculty` (`faculty_id`),
  CONSTRAINT `fk_acta_act` FOREIGN KEY (`activity_id`) REFERENCES `extension_activities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_acta_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `activity_assignments` VALUES ('2','1','5','member','1','2026-07-29 17:25:11','1');
INSERT INTO `activity_assignments` VALUES ('4','2','5','member','1','2026-07-29 17:25:11','1');
INSERT INTO `activity_assignments` VALUES ('6','3','5','member','1','2026-07-29 17:25:11','1');
INSERT INTO `activity_assignments` VALUES ('9','6','4','leader','1','2026-07-29 17:25:11','1');
INSERT INTO `activity_assignments` VALUES ('10','7','4','leader','1','2026-07-29 17:25:11','1');
INSERT INTO `activity_assignments` VALUES ('11','8','5','leader','1','2026-07-29 17:25:11','1');
CREATE TABLE `activity_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) NOT NULL,
  `participant_id` int(11) NOT NULL,
  `session_date` date NOT NULL,
  `time_in` time DEFAULT NULL,
  `time_out` time DEFAULT NULL,
  `status` enum('present','absent','excused') NOT NULL DEFAULT 'present',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_att_activity` (`activity_id`),
  KEY `fk_att_participant` (`participant_id`),
  CONSTRAINT `fk_att_activity` FOREIGN KEY (`activity_id`) REFERENCES `extension_activities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_att_participant` FOREIGN KEY (`participant_id`) REFERENCES `activity_participants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `activity_attendance` VALUES ('1','1','1','2026-03-15','08:00:00','17:00:00','present','2026-07-29 17:25:11');
INSERT INTO `activity_attendance` VALUES ('2','1','1','2026-03-16','08:00:00','17:00:00','present','2026-07-29 17:25:11');
INSERT INTO `activity_attendance` VALUES ('3','1','1','2026-03-17','08:00:00','17:00:00','present','2026-07-29 17:25:11');
INSERT INTO `activity_attendance` VALUES ('4','1','2','2026-03-15','08:00:00','17:00:00','present','2026-07-29 17:25:11');
INSERT INTO `activity_attendance` VALUES ('5','1','2','2026-03-16','08:00:00','17:00:00','present','2026-07-29 17:25:11');
INSERT INTO `activity_attendance` VALUES ('6','1','2','2026-03-17','08:15:00','17:00:00','present','2026-07-29 17:25:11');
INSERT INTO `activity_attendance` VALUES ('7','1','3','2026-03-15','08:00:00','17:00:00','present','2026-07-29 17:25:11');
INSERT INTO `activity_attendance` VALUES ('8','1','3','2026-03-16','08:00:00','12:00:00','present','2026-07-29 17:25:11');
INSERT INTO `activity_attendance` VALUES ('9','1','3','2026-03-17',NULL,NULL,'absent','2026-07-29 17:25:11');
CREATE TABLE `activity_evaluations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) NOT NULL,
  `participant_id` int(11) DEFAULT NULL,
  `overall_rating` int(1) DEFAULT NULL,
  `content_rating` int(1) DEFAULT NULL,
  `speaker_rating` int(1) DEFAULT NULL,
  `venue_rating` int(1) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_eval_activity` (`activity_id`),
  CONSTRAINT `fk_eval_activity` FOREIGN KEY (`activity_id`) REFERENCES `extension_activities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `activity_evaluations` VALUES ('1','1','1','5','5','5','4','Very informative training. Learned a lot about organic farming.','2026-07-29 17:25:11');
INSERT INTO `activity_evaluations` VALUES ('2','1','2','4','4','5','4','Good training, would like more hands-on practice.','2026-07-29 17:25:11');
INSERT INTO `activity_evaluations` VALUES ('3','1','3','5','5','5','5','Excellent! Will apply what I learned on my farm.','2026-07-29 17:25:11');
INSERT INTO `activity_evaluations` VALUES ('4','4','6','5','5','5','5','Great workshop! Now I can bake bread for my family.','2026-07-29 17:25:11');
INSERT INTO `activity_evaluations` VALUES ('5','4','7','4','4','4','4','Enjoyed the workshop. Want to learn more recipes.','2026-07-29 17:25:11');
CREATE TABLE `activity_outputs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `output_type` enum('material','report','certificate','other') DEFAULT 'other',
  `file_path` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_output_activity` (`activity_id`),
  CONSTRAINT `fk_output_activity` FOREIGN KEY (`activity_id`) REFERENCES `extension_activities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `activity_outputs` VALUES ('1','1','Organic Fertilizer Production Manual','Step-by-step guide for producing organic fertilizers.','material',NULL,'1','2026-07-29 17:25:11');
INSERT INTO `activity_outputs` VALUES ('2','4','Bread Making Recipe Book','Collection of bread recipes taught during the workshop.','material',NULL,'1','2026-07-29 17:25:11');
INSERT INTO `activity_outputs` VALUES ('3','6','Computer Basics Training Guide','Guide for basic computer operations.','material',NULL,'1','2026-07-29 17:25:11');
CREATE TABLE `activity_participants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) NOT NULL,
  `beneficiary_group_id` int(11) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `age` int(3) DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `address` text DEFAULT NULL,
  `barangay` varchar(100) DEFAULT NULL,
  `municipality` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `organization` varchar(200) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `emergency_contact` varchar(200) DEFAULT NULL,
  `emergency_phone` varchar(20) DEFAULT NULL,
  `attendance_status` enum('registered','present','absent') NOT NULL DEFAULT 'registered',
  `certificate_status` enum('not_issued','issued','claimed') NOT NULL DEFAULT 'not_issued',
  `qr_code` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `qr_code` (`qr_code`),
  KEY `fk_ap_activity` (`activity_id`),
  KEY `fk_ap_beneficiary` (`beneficiary_group_id`),
  CONSTRAINT `fk_ap_activity` FOREIGN KEY (`activity_id`) REFERENCES `extension_activities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ap_beneficiary` FOREIGN KEY (`beneficiary_group_id`) REFERENCES `beneficiary_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `activity_participants` VALUES ('1','1',NULL,'Pedro Santos','45','male',NULL,'San Isidro','Cauayan','Isabela','San Isidro Farmers Association','Farmer',NULL,NULL,NULL,NULL,'present','issued','QR-FARM001','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `activity_participants` VALUES ('2','1',NULL,'Maria Reyes','38','female',NULL,'San Isidro','Cauayan','Isabela','San Isidro Farmers Association','Farmer',NULL,NULL,NULL,NULL,'present','issued','QR-FARM002','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `activity_participants` VALUES ('3','1',NULL,'Juan Cruz','52','male',NULL,'San Isidro','Cauayan','Isabela','','Farmer',NULL,NULL,NULL,NULL,'present','issued','QR-FARM003','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `activity_participants` VALUES ('4','1',NULL,'Lorna Garcia','41','female',NULL,'San Isidro','Cauayan','Isabela','','Farmer',NULL,NULL,NULL,NULL,'present','issued','QR-FARM004','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `activity_participants` VALUES ('5','1',NULL,'Ricardo Bautista','55','male',NULL,'San Isidro','Cauayan','Isabela','','Farmer',NULL,NULL,NULL,NULL,'present','not_issued','QR-FARM005','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `activity_participants` VALUES ('6','4',NULL,'Ana Mendoza','22','female',NULL,'District I','Cauayan','Isabela','OSY Program','Student',NULL,NULL,NULL,NULL,'present','issued','QR-BAKE001','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `activity_participants` VALUES ('7','4',NULL,'Mark Reyes','20','male',NULL,'District II','Cauayan','Isabela','','Student',NULL,NULL,NULL,NULL,'present','issued','QR-BAKE002','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `activity_participants` VALUES ('8','4',NULL,'Linda Garcia','24','female',NULL,'Poblacion','Cauayan','Isabela','','Student',NULL,NULL,NULL,NULL,'present','not_issued','QR-BAKE003','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `activity_participants` VALUES ('9','6',NULL,'Lorna Garcia','65','female',NULL,'District I','Cauayan','Isabela','Senior Citizens Association','Retired',NULL,NULL,NULL,NULL,'present','issued','QR-DIGI001','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `activity_participants` VALUES ('10','6',NULL,'Ricardo Bautista','70','male',NULL,'District I','Cauayan','Isabela','Senior Citizens Association','Retired',NULL,NULL,NULL,NULL,'present','issued','QR-DIGI002','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `activity_participants` VALUES ('11','8',NULL,'Antonio Mendoza','48','male',NULL,'Minante','Cauayan','Isabela','Corn Farmers Association','Farmer',NULL,NULL,NULL,NULL,'present','issued','QR-CORN001','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `activity_participants` VALUES ('12','8',NULL,'Roberto Cruz','39','male',NULL,'Minante','Cauayan','Isabela','','Farmer',NULL,NULL,NULL,NULL,'present','issued','QR-CORN002','2026-07-29 17:25:11','2026-07-29 17:25:11');
CREATE TABLE `activity_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `uploaded_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_photo_activity` (`activity_id`),
  CONSTRAINT `fk_photo_activity` FOREIGN KEY (`activity_id`) REFERENCES `extension_activities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `activity_photos` VALUES ('1','1','activities/organic_training_1.jpg','Farmers learning organic fertilizer production','1','2026-07-29 17:25:11');
INSERT INTO `activity_photos` VALUES ('2','1','activities/organic_training_2.jpg','Hands-on composting practice','1','2026-07-29 17:25:11');
INSERT INTO `activity_photos` VALUES ('3','4','activities/bread_workshop_1.jpg','Youth learning bread making','1','2026-07-29 17:25:11');
INSERT INTO `activity_photos` VALUES ('4','6','activities/computer_class_1.jpg','Seniors learning computer basics','1','2026-07-29 17:25:11');
INSERT INTO `activity_photos` VALUES ('5','8','activities/corn_training_1.jpg','Modern corn production techniques','1','2026-07-29 17:25:11');
CREATE TABLE `activity_resource_speakers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `affiliation` varchar(200) DEFAULT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_speaker_activity` (`activity_id`),
  CONSTRAINT `fk_speaker_activity` FOREIGN KEY (`activity_id`) REFERENCES `extension_activities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `activity_resource_speakers` VALUES ('1','1','Dr. Elena Torres','DA-Isabela','Organic Fertilizer Production','09171234600','torres@da.gov.ph','2026-07-29 17:25:11');
INSERT INTO `activity_resource_speakers` VALUES ('2','1','Prof. Mark Santos','ISU-Echague','Composting Techniques','09171234601','santos@isu.edu.ph','2026-07-29 17:25:11');
INSERT INTO `activity_resource_speakers` VALUES ('3','2','Dr. Roberto Lim','ISU-Cauayan','Natural Pest Control','09171234602','lim@isu.edu.ph','2026-07-29 17:25:11');
INSERT INTO `activity_resource_speakers` VALUES ('4','6','Ms. Jennifer Lee','DepEd Isabela','Basic Computer Skills','09171234603','lee@deped.gov.ph','2026-07-29 17:25:11');
CREATE TABLE `activity_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `activity_types` VALUES ('1','Training','1','2026-07-29 17:25:11');
INSERT INTO `activity_types` VALUES ('2','Seminar','1','2026-07-29 17:25:11');
INSERT INTO `activity_types` VALUES ('3','Workshop','1','2026-07-29 17:25:11');
INSERT INTO `activity_types` VALUES ('4','Orientation','1','2026-07-29 17:25:11');
INSERT INTO `activity_types` VALUES ('5','Monitoring','1','2026-07-29 17:25:11');
INSERT INTO `activity_types` VALUES ('6','Evaluation','1','2026-07-29 17:25:11');
INSERT INTO `activity_types` VALUES ('7','Turnover','1','2026-07-29 17:25:11');
INSERT INTO `activity_types` VALUES ('8','Meeting','1','2026-07-29 17:25:11');
INSERT INTO `activity_types` VALUES ('9','Field Visit','1','2026-07-29 17:25:11');
INSERT INTO `activity_types` VALUES ('10','Technology Demonstration','1','2026-07-29 17:25:11');
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `is_override` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_audit_user` (`user_id`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `audit_logs` VALUES ('1','1','create','program','1','Created program: Community Development and Livelihood Program',NULL,NULL,'127.0.0.1',NULL,'0','2026-07-29 17:25:11');
INSERT INTO `audit_logs` VALUES ('2','1','create','project','1','Created project: Organic Farming Technology Transfer',NULL,NULL,'127.0.0.1',NULL,'0','2026-07-29 17:25:11');
INSERT INTO `audit_logs` VALUES ('3','1','approve','proposal','1','Approved proposal for Organic Farming Technology Transfer',NULL,NULL,'127.0.0.1',NULL,'0','2026-07-29 17:25:11');
INSERT INTO `audit_logs` VALUES ('4','1','approve','proposal','2','Approved proposal for Livelihood Skills Training',NULL,NULL,'127.0.0.1',NULL,'0','2026-07-29 17:25:11');
INSERT INTO `audit_logs` VALUES ('5','1','approve','report','1','Approved Q1 accomplishment report',NULL,NULL,'127.0.0.1',NULL,'0','2026-07-29 17:25:11');
INSERT INTO `audit_logs` VALUES ('6','3','create','proposal','1','Submitted proposal: Organic Farming Technology Transfer',NULL,NULL,'127.0.0.1',NULL,'0','2026-07-29 17:25:11');
INSERT INTO `audit_logs` VALUES ('7','3','login','user','3','User logged in',NULL,NULL,'127.0.0.1',NULL,'0','2026-07-29 17:25:11');
INSERT INTO `audit_logs` VALUES ('8','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1',NULL,'0','2026-07-29 17:25:11');
INSERT INTO `audit_logs` VALUES ('9','1','logout','user','1','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 17:33:28');
INSERT INTO `audit_logs` VALUES ('10','3','login','user','3','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 17:33:31');
INSERT INTO `audit_logs` VALUES ('11','3','logout','user','3','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 17:34:13');
INSERT INTO `audit_logs` VALUES ('12','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 17:34:16');
INSERT INTO `audit_logs` VALUES ('13','1','edit','program_assignment','2','Updated assignments for program: Digital Literacy and ICT Skills Development',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:08:57');
INSERT INTO `audit_logs` VALUES ('14','1','edit','program_assignment','2','Updated assignments for program: Digital Literacy and ICT Skills Development',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:09:16');
INSERT INTO `audit_logs` VALUES ('15','1','edit','program_assignment','2','Updated assignments for program: Digital Literacy and ICT Skills Development',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:09:35');
INSERT INTO `audit_logs` VALUES ('16','1','logout','user','1','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:11:53');
INSERT INTO `audit_logs` VALUES ('17','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:11:59');
INSERT INTO `audit_logs` VALUES ('18','1','logout','user','1','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:12:25');
INSERT INTO `audit_logs` VALUES ('19','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:12:31');
INSERT INTO `audit_logs` VALUES ('20','1','logout','user','1','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:13:35');
INSERT INTO `audit_logs` VALUES ('21','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:13:40');
INSERT INTO `audit_logs` VALUES ('22','1','logout','user','1','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:13:46');
INSERT INTO `audit_logs` VALUES ('23','2','login','user','2','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:13:52');
INSERT INTO `audit_logs` VALUES ('24','2','logout','user','2','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:14:36');
INSERT INTO `audit_logs` VALUES ('25','3','login','user','3','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:14:43');
INSERT INTO `audit_logs` VALUES ('26','3','logout','user','3','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:20:54');
INSERT INTO `audit_logs` VALUES ('27','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:20:57');
INSERT INTO `audit_logs` VALUES ('28','1','logout','user','1','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:24:43');
INSERT INTO `audit_logs` VALUES ('29','3','login','user','3','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:24:47');
INSERT INTO `audit_logs` VALUES ('30','3','logout','user','3','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:27:38');
INSERT INTO `audit_logs` VALUES ('31','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:27:41');
INSERT INTO `audit_logs` VALUES ('32','1','logout','user','1','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:54:04');
INSERT INTO `audit_logs` VALUES ('33','3','login','user','3','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:54:07');
INSERT INTO `audit_logs` VALUES ('34','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:54:23');
INSERT INTO `audit_logs` VALUES ('35','1','edit','program_assignment','3','Updated assignments for program: Agricultural Technology Transfer Program',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:54:45');
INSERT INTO `audit_logs` VALUES ('36','1','edit','program_assignment','2','Updated assignments for program: Digital Literacy and ICT Skills Development',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:55:07');
INSERT INTO `audit_logs` VALUES ('37','1','edit','program_assignment','1','Updated assignments for program: Community Development and Livelihood Program',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 18:55:21');
INSERT INTO `audit_logs` VALUES ('38','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-29 19:32:44');
INSERT INTO `audit_logs` VALUES ('39','3','logout','user','3','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:31:57');
INSERT INTO `audit_logs` VALUES ('40','3','login','user','3','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:32:01');
INSERT INTO `audit_logs` VALUES ('41','3','logout','user','3','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:32:58');
INSERT INTO `audit_logs` VALUES ('42','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:33:01');
INSERT INTO `audit_logs` VALUES ('43','1','edit','project_assignment','1','Updated assignments for project: Organic Farming Technology Transfer',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:33:24');
INSERT INTO `audit_logs` VALUES ('44','1','edit','project_assignment','2','Updated assignments for project: Livelihood Skills Training: Bread and Pastry Making',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:33:36');
INSERT INTO `audit_logs` VALUES ('45','1','edit','project_assignment','4','Updated assignments for project: Corn Production Technology Dissemination',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:34:06');
INSERT INTO `audit_logs` VALUES ('46','1','edit','project_assignment','5','Updated assignments for project: Community Health and Nutrition Awareness',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:34:24');
INSERT INTO `audit_logs` VALUES ('47','1','logout','user','1','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:34:38');
INSERT INTO `audit_logs` VALUES ('48','3','login','user','3','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:34:41');
INSERT INTO `audit_logs` VALUES ('49','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:35:15');
INSERT INTO `audit_logs` VALUES ('50','1','edit','program_assignment','1','Updated assignments for program: Community Development and Livelihood Program',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:39:41');
INSERT INTO `audit_logs` VALUES ('51','1','edit','program_assignment','1','Updated assignments for program: Community Development and Livelihood Program',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:40:16');
INSERT INTO `audit_logs` VALUES ('52','1','edit','program_assignment','1','Updated assignments for program: Community Development and Livelihood Program',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 09:42:06');
INSERT INTO `audit_logs` VALUES ('53','1','edit','program_assignment','3','Updated assignments for program: Agricultural Technology Transfer Program',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 10:55:58');
INSERT INTO `audit_logs` VALUES ('54','1','edit','program_assignment','3','Updated assignments for program: Agricultural Technology Transfer Program',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 10:56:25');
INSERT INTO `audit_logs` VALUES ('55','1','edit','program_assignment','1','Updated assignments for program: Community Development and Livelihood Program',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 11:04:27');
INSERT INTO `audit_logs` VALUES ('56','1','edit','project_assignment','4','Updated assignments for project: Corn Production Technology Dissemination',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 12:03:36');
INSERT INTO `audit_logs` VALUES ('57','1','create','activity','9','Created activity: Testing',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 12:05:08');
INSERT INTO `audit_logs` VALUES ('58','1','edit','project_assignment','4','Updated assignments for project: Corn Production Technology Dissemination',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 12:26:55');
INSERT INTO `audit_logs` VALUES ('59','3','create','proposal','7','Submitted program proposal: Test',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 12:49:55');
INSERT INTO `audit_logs` VALUES ('60','1','approved','proposal','7','Approved proposal',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 12:57:43');
INSERT INTO `audit_logs` VALUES ('61','1','approved','proposal','7','Approved proposal',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 13:02:55');
INSERT INTO `audit_logs` VALUES ('62','1','approved','proposal','7','Approved proposal',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 13:12:33');
INSERT INTO `audit_logs` VALUES ('63','1','edit','project','0','Updated project',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 13:19:53');
INSERT INTO `audit_logs` VALUES ('64','1','edit','project','0','Updated project',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 13:20:21');
INSERT INTO `audit_logs` VALUES ('65','1','edit','project','4','Updated project',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','0','2026-07-30 13:35:04');
INSERT INTO `audit_logs` VALUES ('66','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-06 22:14:59');
INSERT INTO `audit_logs` VALUES ('67','1','logout','user','1','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 16:56:16');
INSERT INTO `audit_logs` VALUES ('68','3','login','user','3','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 16:56:22');
INSERT INTO `audit_logs` VALUES ('69','3','edit','project_assignment','4','Updated assignments for project: Corn Production Technology Dissemination',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 16:57:35');
INSERT INTO `audit_logs` VALUES ('70','3','logout','user','3','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 16:57:55');
INSERT INTO `audit_logs` VALUES ('71','5','login','user','5','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 16:58:48');
INSERT INTO `audit_logs` VALUES ('72','5','logout','user','5','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 16:59:26');
INSERT INTO `audit_logs` VALUES ('73','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 16:59:30');
INSERT INTO `audit_logs` VALUES ('74','1','logout','user','1','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 17:43:57');
INSERT INTO `audit_logs` VALUES ('75','3','login','user','3','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 17:44:00');
INSERT INTO `audit_logs` VALUES ('76','3','logout','user','3','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 17:44:19');
INSERT INTO `audit_logs` VALUES ('77','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 17:44:23');
INSERT INTO `audit_logs` VALUES ('78','1','returned','proposal','5','Returned proposal',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 17:45:30');
INSERT INTO `audit_logs` VALUES ('79','1','logout','user','1','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 17:45:35');
INSERT INTO `audit_logs` VALUES ('80','3','login','user','3','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 17:45:38');
INSERT INTO `audit_logs` VALUES ('81','3','logout','user','3','User logged out',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 17:49:13');
INSERT INTO `audit_logs` VALUES ('82','1','login','user','1','User logged in',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','0','2026-09-08 17:49:17');
CREATE TABLE `beneficiary_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `group_type` enum('individual','organization','community','lgu') DEFAULT NULL,
  `barangay` varchar(100) DEFAULT NULL,
  `municipality` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `contact_person` varchar(200) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `beneficiary_groups` VALUES ('1','San Isidro Farmers Association','organization','San Isidro','Cauayan','Isabela','Pedro Santos','09171234590','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `beneficiary_groups` VALUES ('2','District I Senior Citizens','organization','District I','Cauayan','Isabela','Lorna Garcia','09171234591','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `beneficiary_groups` VALUES ('3','Cauayan Youth Organization','organization','Poblacion','Cauayan','Isabela','Mark Reyes','09171234592','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `beneficiary_groups` VALUES ('4','Rizal Organic Farmers Cooperative','organization','Rizal','Cauayan','Isabela','Juan Ramos','09171234593','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `beneficiary_groups` VALUES ('5','Villa Luna Women\'s Association','organization','Villa Luna','Cauayan','Isabela','Maria Bautista','09171234594','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `beneficiary_groups` VALUES ('6','District II Parents Association','organization','District II','Cauayan','Isabela','Roberto Cruz','09171234595','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `beneficiary_groups` VALUES ('7','Cauayan Corn Farmers Association','organization','Minante','Cauayan','Isabela','Antonio Mendoza','09171234596','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `beneficiary_groups` VALUES ('8','Cauayan LGU','lgu','','Cauayan','Isabela','Mayor Office','09171234597','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
CREATE TABLE `certificate_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` enum('participation','completion','recognition','appreciation') NOT NULL,
  `template_path` varchar(255) DEFAULT NULL,
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `certificate_templates` VALUES ('1','Certificate of Participation','participation',NULL,'[\"recipient_name\",\"activity_title\",\"date\",\"venue\"]','1','2026-07-29 17:25:11');
INSERT INTO `certificate_templates` VALUES ('2','Certificate of Completion','completion',NULL,'[\"recipient_name\",\"program_title\",\"date\"]','1','2026-07-29 17:25:11');
INSERT INTO `certificate_templates` VALUES ('3','Certificate of Recognition','recognition',NULL,'[\"recipient_name\",\"achievement\",\"date\"]','1','2026-07-29 17:25:11');
INSERT INTO `certificate_templates` VALUES ('4','Certificate of Appreciation','appreciation',NULL,'[\"recipient_name\",\"contribution\",\"date\"]','1','2026-07-29 17:25:11');
CREATE TABLE `certificates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `certificate_number` varchar(30) NOT NULL,
  `template_id` int(11) DEFAULT NULL,
  `activity_id` int(11) DEFAULT NULL,
  `recipient_name` varchar(200) NOT NULL,
  `recipient_type` enum('participant','resource_speaker') NOT NULL DEFAULT 'participant',
  `date_issued` date DEFAULT NULL,
  `qr_code` varchar(100) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `status` enum('generated','printed','claimed') NOT NULL DEFAULT 'generated',
  `generated_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `certificate_number` (`certificate_number`),
  KEY `fk_cert_template` (`template_id`),
  KEY `fk_cert_activity` (`activity_id`),
  CONSTRAINT `fk_cert_activity` FOREIGN KEY (`activity_id`) REFERENCES `extension_activities` (`id`),
  CONSTRAINT `fk_cert_template` FOREIGN KEY (`template_id`) REFERENCES `certificate_templates` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `certificates` VALUES ('1','CERT-2026-0001','1','1','Pedro Santos','participant','2026-03-17','CERT-QR001',NULL,'','1','2026-07-29 17:25:11');
INSERT INTO `certificates` VALUES ('2','CERT-2026-0002','1','1','Maria Reyes','participant','2026-03-17','CERT-QR002',NULL,'','1','2026-07-29 17:25:11');
INSERT INTO `certificates` VALUES ('3','CERT-2026-0003','1','4','Ana Mendoza','participant','2026-04-03','CERT-QR003',NULL,'','1','2026-07-29 17:25:11');
INSERT INTO `certificates` VALUES ('4','CERT-2026-0004','1','6','Lorna Garcia','participant','2026-03-05','CERT-QR004',NULL,'','1','2026-07-29 17:25:11');
INSERT INTO `certificates` VALUES ('5','CERT-2026-0005','4','1','Dr. Elena Torres','resource_speaker','2026-03-17','CERT-QR005',NULL,'','1','2026-07-29 17:25:11');
CREATE TABLE `component_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `component_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `assignment_type` enum('leader','member') NOT NULL DEFAULT 'member',
  `assigned_by` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comp_faculty` (`component_id`,`faculty_id`),
  KEY `fk_compa_comp` (`component_id`),
  KEY `fk_compa_faculty` (`faculty_id`),
  CONSTRAINT `fk_compa_comp` FOREIGN KEY (`component_id`) REFERENCES `components` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_compa_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `component_assignments` VALUES ('2','1','5','member','1','2026-07-29 17:25:11','1');
INSERT INTO `component_assignments` VALUES ('5','4','4','leader','1','2026-07-29 17:25:11','1');
INSERT INTO `component_assignments` VALUES ('6','5','5','leader','1','2026-07-29 17:25:11','1');
CREATE TABLE `components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `component_code` varchar(30) NOT NULL,
  `project_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('planned','in_progress','completed','cancelled') NOT NULL DEFAULT 'planned',
  `expected_outputs` text DEFAULT NULL,
  `completion_percentage` int(3) NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `component_code` (`component_code`),
  KEY `fk_comp_project` (`project_id`),
  KEY `fk_comp_creator` (`created_by`),
  CONSTRAINT `fk_comp_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_comp_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `components` VALUES ('1','COMP-2026-0001','1','Farmer Training Component','Series of training sessions for local farmers on organic farming.','2026-02-01','2026-06-30','in_progress','Trained farmers, training manuals, demonstration plots','50','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `components` VALUES ('2','COMP-2026-0002','1','Technology Demonstration Component','Establishment of demonstration farms for organic techniques.','2026-03-01','2026-10-31','in_progress','Demo farms, documented results, farmer adoption','30','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `components` VALUES ('3','COMP-2026-0003','2','Baking Skills Training','Hands-on bread and pastry making workshops.','2026-03-15','2026-07-31','in_progress','Skilled youth, recipe book, products','40','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `components` VALUES ('4','COMP-2026-0004','3','Computer Basics Workshop','Basic computer operations and internet skills.','2026-02-15','2026-05-31','completed','Computer literate seniors, training guides','100','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `components` VALUES ('5','COMP-2026-0005','4','Corn Production Training','Training on modern corn production techniques.','2026-02-01','2026-06-30','in_progress','Trained farmers, production guide','20','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `departments` VALUES ('1','College of Agriculture','CA','1','2026-07-29 17:25:11');
INSERT INTO `departments` VALUES ('2','College of Engineering','CE','1','2026-07-29 17:25:11');
INSERT INTO `departments` VALUES ('3','College of Education','CED','1','2026-07-29 17:25:11');
INSERT INTO `departments` VALUES ('4','College of Arts and Sciences','CAS','1','2026-07-29 17:25:11');
INSERT INTO `departments` VALUES ('5','College of Business and Accountancy','CBA','1','2026-07-29 17:25:11');
INSERT INTO `departments` VALUES ('6','College of Computing and Information Sciences','CCIS','1','2026-07-29 17:25:11');
INSERT INTO `departments` VALUES ('7','College of Veterinary Medicine','CVM','1','2026-07-29 17:25:11');
INSERT INTO `departments` VALUES ('8','College of Nursing','CN','1','2026-07-29 17:25:11');
INSERT INTO `departments` VALUES ('9','Extension Training Services','ETS','1','2026-07-29 17:25:11');
CREATE TABLE `document_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `document_categories` VALUES ('1','Proposals','Project proposals','1','2026-07-29 17:25:11');
INSERT INTO `document_categories` VALUES ('2','MOA','Memorandum of Agreement','1','2026-07-29 17:25:11');
INSERT INTO `document_categories` VALUES ('3','Accomplishment Reports','Quarterly and annual reports','1','2026-07-29 17:25:11');
INSERT INTO `document_categories` VALUES ('4','Narrative Reports','Activity narrative reports','1','2026-07-29 17:25:11');
INSERT INTO `document_categories` VALUES ('5','Terminal Reports','Project completion reports','1','2026-07-29 17:25:11');
INSERT INTO `document_categories` VALUES ('6','Attendance Sheets','Participant attendance records','1','2026-07-29 17:25:11');
INSERT INTO `document_categories` VALUES ('7','Certificates','Generated certificates','1','2026-07-29 17:25:11');
INSERT INTO `document_categories` VALUES ('8','Photos','Activity documentation photos','1','2026-07-29 17:25:11');
INSERT INTO `document_categories` VALUES ('9','Evaluation Forms','Post-activity evaluations','1','2026-07-29 17:25:11');
INSERT INTO `document_categories` VALUES ('10','Letters','Official correspondence','1','2026-07-29 17:25:11');
INSERT INTO `document_categories` VALUES ('11','Supporting Documents','Other supporting files','1','2026-07-29 17:25:11');
CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `entity_type` enum('program','project','component','activity') NOT NULL,
  `entity_id` int(11) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `status` enum('draft','submitted','approved','archived') NOT NULL DEFAULT 'draft',
  `uploaded_by` int(11) NOT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_doc_category` (`category_id`),
  KEY `fk_doc_uploader` (`uploaded_by`),
  CONSTRAINT `fk_doc_category` FOREIGN KEY (`category_id`) REFERENCES `document_categories` (`id`),
  CONSTRAINT `fk_doc_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `documents` VALUES ('1','Organic Farming Proposal','1','project','1','documents/proposal_organic.pdf','proposal_organic.pdf','pdf',NULL,'1','Initial project proposal','approved','3',NULL,NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `documents` VALUES ('2','MOA with City Agriculture','2','project','1','documents/moa_agriculture.pdf','moa_agriculture.pdf','pdf',NULL,'1','Memorandum of Agreement','approved','1',NULL,NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `documents` VALUES ('3','Training Attendance Sheet','6','activity','1','documents/attendance_training.pdf','attendance_training.pdf','pdf',NULL,'1','Attendance for organic farming training','approved','3',NULL,NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `documents` VALUES ('4','Q1 Report 2026','3','project','1','documents/q1_report.pdf','q1_report.pdf','pdf',NULL,'1','Quarterly accomplishment report','approved','3',NULL,NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
CREATE TABLE `extension_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_code` varchar(30) NOT NULL,
  `component_id` int(11) NOT NULL,
  `activity_type_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `objectives` text DEFAULT NULL,
  `venue` varchar(255) DEFAULT NULL,
  `start_datetime` datetime DEFAULT NULL,
  `end_datetime` datetime DEFAULT NULL,
  `target_participants` int(11) DEFAULT NULL,
  `budget_allocation` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` enum('planned','ongoing','completed','cancelled') NOT NULL DEFAULT 'planned',
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `activity_code` (`activity_code`),
  KEY `fk_act_component` (`component_id`),
  KEY `fk_act_type` (`activity_type_id`),
  KEY `fk_act_creator` (`created_by`),
  CONSTRAINT `fk_act_component` FOREIGN KEY (`component_id`) REFERENCES `components` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_act_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_act_type` FOREIGN KEY (`activity_type_id`) REFERENCES `activity_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `extension_activities` VALUES ('1','ACT-2026-0001','1','1','Organic Fertilizer Production Training','Hands-on training on producing organic fertilizers from local materials.','Teach farmers to produce organic fertilizer','Brgy. San Isidro Hall','2026-03-15 08:00:00','2026-03-17 17:00:00','50','35000.00','completed','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `extension_activities` VALUES ('2','ACT-2026-0002','1','1','Pest Management in Organic Farming','Training on natural pest control methods.','Equip farmers with organic pest management skills','Brgy. San Isidro Hall','2026-04-15 08:00:00','2026-04-16 17:00:00','45','25000.00','completed','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `extension_activities` VALUES ('3','ACT-2026-0003','1','10','Organic Farm Demonstration','On-site demonstration of organic farming techniques.','Show practical application of organic farming','Demo Farm, San Isidro','2026-05-10 08:00:00','2026-05-10 17:00:00','40','15000.00','completed','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `extension_activities` VALUES ('4','ACT-2026-0004','3','3','Bread Making Workshop','Hands-on bread making workshop for youth.','Teach bread making skills','ISU-Cauayan Bakery Lab','2026-04-01 08:00:00','2026-04-03 17:00:00','25','20000.00','completed','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `extension_activities` VALUES ('5','ACT-2026-0005','3','3','Pastry Decoration Workshop','Advanced pastry techniques and decoration.','Teach pastry decoration skills','ISU-Cauayan Bakery Lab','2026-05-01 08:00:00','2026-05-02 17:00:00','25','18000.00','completed','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `extension_activities` VALUES ('6','ACT-2026-0006','4','3','Basic Computer Operations','Introduction to computers, typing, and file management.','Teach basic computer skills','ISU-Cauayan Computer Lab','2026-03-01 09:00:00','2026-03-05 16:00:00','30','15000.00','completed','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `extension_activities` VALUES ('7','ACT-2026-0007','4','3','Internet and Email Workshop','Using internet, email, and online services.','Teach internet navigation','ISU-Cauayan Computer Lab','2026-04-01 09:00:00','2026-04-03 16:00:00','30','12000.00','completed','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `extension_activities` VALUES ('8','ACT-2026-0008','5','1','Modern Corn Production Techniques','Training on improved corn varieties and production methods.','Introduce modern corn farming','Minante Agricultural Center','2026-03-20 08:00:00','2026-03-22 17:00:00','60','30000.00','completed','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `extension_activities` VALUES ('9','ACT-2026-0009','5','3','Testing','Test','Blablabla','San fermin','2026-07-30 18:00:00','2026-07-30 19:00:00','25','25000.00','planned','1','2026-07-30 12:05:08','2026-07-30 12:05:08',NULL);
CREATE TABLE `faculty_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `employee_id` varchar(20) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `specialization` text DEFAULT NULL,
  `is_extensionist` tinyint(1) NOT NULL DEFAULT 0,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  KEY `fk_fp_dept` (`department_id`),
  CONSTRAINT `fk_fp_dept` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `fk_fp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `faculty_profiles` VALUES ('1','1','EMP-001','System','Administrator','','9','System Administrator','09171234567','admin@isu-cauayan.edu.ph','','0',NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `faculty_profiles` VALUES ('2','2','EMP-002','Roberto','Mendoza','Santos','9','ETS Head','09171234568','ets.head@isu-cauayan.edu.ph','Extension Program Management','1',NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `faculty_profiles` VALUES ('3','3','EMP-003','Juan','Dela Cruz','Reyes','1','Instructor III','09171234569','juan.delacruz@isu-cauayan.edu.ph','Organic Farming, Crop Production','1',NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `faculty_profiles` VALUES ('4','4','EMP-004','Maria','Santos','Garcia','6','Assistant Professor II','09171234570','maria.santos@isu-cauayan.edu.ph','Information Technology, Digital Literacy','1',NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `faculty_profiles` VALUES ('5','5','EMP-005','Pedro','Reyes','Cruz','1','Associate Professor I','09171234571','pedro.reyes@isu-cauayan.edu.ph','Animal Science, Livestock','1',NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `faculty_profiles` VALUES ('6','6','EMP-006','Ana','Garcia','Lopez','3','Instructor II','09171234572','ana.garcia@isu-cauayan.edu.ph','Community Education, Literacy','1',NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `faculty_profiles` VALUES ('7','7','EMP-007','Dean','Official','','4','College Dean','09171234573','dean@isu-cauayan.edu.ph','','0',NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11');
CREATE TABLE `funding_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `funding_sources` VALUES ('1','University Fund','Internal ISU funding','1','2026-07-29 17:25:11');
INSERT INTO `funding_sources` VALUES ('2','CHED','Commission on Higher Education','1','2026-07-29 17:25:11');
INSERT INTO `funding_sources` VALUES ('3','DOST','Department of Science and Technology','1','2026-07-29 17:25:11');
INSERT INTO `funding_sources` VALUES ('4','DA','Department of Agriculture','1','2026-07-29 17:25:11');
INSERT INTO `funding_sources` VALUES ('5','LGU','Local Government Unit - Cauayan City','1','2026-07-29 17:25:11');
INSERT INTO `funding_sources` VALUES ('6','External Grant','External grants and donations','1','2026-07-29 17:25:11');
INSERT INTO `funding_sources` VALUES ('7','GAA','General Appropriations Act','1','2026-07-29 17:25:11');
CREATE TABLE `moas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `moa_number` varchar(30) NOT NULL,
  `project_id` int(11) NOT NULL,
  `partner_agency_id` int(11) DEFAULT NULL,
  `date_signed` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `status` enum('pending','active','expired','terminated') NOT NULL DEFAULT 'pending',
  `attachment` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `moa_number` (`moa_number`),
  KEY `fk_moa_project` (`project_id`),
  KEY `fk_moa_partner` (`partner_agency_id`),
  CONSTRAINT `fk_moa_partner` FOREIGN KEY (`partner_agency_id`) REFERENCES `partner_agencies` (`id`),
  CONSTRAINT `fk_moa_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `moas` VALUES ('1','MOA-2026-0001','1','1','2026-01-05','2027-01-05','active',NULL,'Partnership for organic farming project','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `moas` VALUES ('2','MOA-2026-0002','3','4','2026-01-25','2026-07-25','active',NULL,'Venue partnership for digital literacy program','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `moas` VALUES ('3','MOA-2025-0003','5','3','2025-05-20','2025-11-20','expired',NULL,'Health program partnership - expired','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','error') NOT NULL DEFAULT 'info',
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `action_url` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_notif_user` (`user_id`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `notifications` VALUES ('1','3','Proposal Approved','Your proposal for \"Organic Farming Technology Transfer\" has been approved.','success',NULL,NULL,'/index.php?module=proposals','1','2026-07-29 17:25:11');
INSERT INTO `notifications` VALUES ('2','3','Report Approved','Your Q1 accomplishment report has been approved.','success',NULL,NULL,'/index.php?module=reports','1','2026-07-29 17:25:11');
INSERT INTO `notifications` VALUES ('3','1','New Proposal Submitted','A new proposal \"Revised Proposal for Phase 2 Training\" has been submitted for review.','info',NULL,NULL,'/index.php?module=proposals','1','2026-07-29 17:25:11');
INSERT INTO `notifications` VALUES ('4','4','Assignment','You have been assigned as Digital Literacy Program Leader.','info',NULL,NULL,'/index.php?module=programs','0','2026-07-29 17:25:11');
INSERT INTO `notifications` VALUES ('5','5','Project Update','Corn Production Technology project is 25% complete.','info',NULL,NULL,'/index.php?module=projects','0','2026-07-29 17:25:11');
INSERT INTO `notifications` VALUES ('6','3','New Leader Assignment','You have been assigned as Leader to Program: Digital Literacy and ICT Skills Development','info','program','2','/index.php?module=programs','1','2026-07-29 18:08:57');
INSERT INTO `notifications` VALUES ('7','1','New Member Assignment','You have been assigned as Member to Program: Digital Literacy and ICT Skills Development','info','program','2','/index.php?module=programs','1','2026-07-29 18:08:57');
INSERT INTO `notifications` VALUES ('8','3','New Member Assignment','You have been assigned as Member to Program: Digital Literacy and ICT Skills Development','info','program','2','/index.php?module=programs','1','2026-07-29 18:08:57');
INSERT INTO `notifications` VALUES ('9','2','New Leader Assignment','You have been assigned as Leader to Program: Digital Literacy and ICT Skills Development','info','program','2','/index.php?module=programs','0','2026-07-29 18:09:16');
INSERT INTO `notifications` VALUES ('10','2','New Leader Assignment','You have been assigned as Leader to Program: Digital Literacy and ICT Skills Development','info','program','2','/index.php?module=programs','0','2026-07-29 18:09:35');
INSERT INTO `notifications` VALUES ('11','3','New Member Assignment','You have been assigned as Member to Program: Digital Literacy and ICT Skills Development','info','program','2','/index.php?module=programs','1','2026-07-29 18:09:35');
INSERT INTO `notifications` VALUES ('12','6','New Leader Assignment','You have been assigned as Leader to Program: Agricultural Technology Transfer Program','info','program','3','/index.php?module=programs','0','2026-07-29 18:54:45');
INSERT INTO `notifications` VALUES ('13','2','New Leader Assignment','You have been assigned as Leader to Program: Digital Literacy and ICT Skills Development','info','program','2','/index.php?module=programs','0','2026-07-29 18:55:07');
INSERT INTO `notifications` VALUES ('14','2','New Leader Assignment','You have been assigned as Leader to Program: Community Development and Livelihood Program','info','program','1','/index.php?module=programs','0','2026-07-29 18:55:21');
INSERT INTO `notifications` VALUES ('15','3','Assignment Removed','You have been removed from Program: Community Development and Livelihood Program','warning','program','1','/index.php?module=programs','1','2026-07-29 18:55:21');
INSERT INTO `notifications` VALUES ('16','2','New Leader Assignment','You have been assigned as Leader to Project: Organic Farming Technology Transfer','info','project','1','/index.php?module=projects','0','2026-07-30 09:33:24');
INSERT INTO `notifications` VALUES ('17','5','Assignment Removed','You have been removed from Project: Organic Farming Technology Transfer','warning','project','1','/index.php?module=projects','0','2026-07-30 09:33:24');
INSERT INTO `notifications` VALUES ('18','2','New Leader Assignment','You have been assigned as Leader to Project: Livelihood Skills Training: Bread and Pastry Making','info','project','2','/index.php?module=projects','0','2026-07-30 09:33:36');
INSERT INTO `notifications` VALUES ('19','5','New Leader Assignment','You have been assigned as Leader to Project: Corn Production Technology Dissemination','info','project','4','/index.php?module=projects','0','2026-07-30 09:34:06');
INSERT INTO `notifications` VALUES ('20','3','Assignment Removed','You have been removed from Project: Corn Production Technology Dissemination','warning','project','4','/index.php?module=projects','1','2026-07-30 09:34:06');
INSERT INTO `notifications` VALUES ('21','2','New Leader Assignment','You have been assigned as Leader to Project: Community Health and Nutrition Awareness','info','project','5','/index.php?module=projects','0','2026-07-30 09:34:24');
INSERT INTO `notifications` VALUES ('22','6','Assignment Removed','You have been removed from Project: Community Health and Nutrition Awareness','warning','project','5','/index.php?module=projects','0','2026-07-30 09:34:24');
INSERT INTO `notifications` VALUES ('23','2','New Leader Assignment','You have been assigned as Leader to Program: Community Development and Livelihood Program','info','program','1','/index.php?module=programs','0','2026-07-30 09:39:41');
INSERT INTO `notifications` VALUES ('24','3','New Member Assignment','You have been assigned as Member to Program: Community Development and Livelihood Program','info','program','1','/index.php?module=programs','1','2026-07-30 09:39:41');
INSERT INTO `notifications` VALUES ('25','2','New Leader Assignment','You have been assigned as Leader to Program: Community Development and Livelihood Program','info','program','1','/index.php?module=programs','0','2026-07-30 09:40:16');
INSERT INTO `notifications` VALUES ('26','3','Assignment Removed','You have been removed from Program: Community Development and Livelihood Program','warning','program','1','/index.php?module=programs','1','2026-07-30 09:40:16');
INSERT INTO `notifications` VALUES ('27','2','New Leader Assignment','You have been assigned as Leader to Program: Community Development and Livelihood Program','info','program','1','/index.php?module=programs','0','2026-07-30 09:42:06');
INSERT INTO `notifications` VALUES ('28','3','New Member Assignment','You have been assigned as Member to Program: Community Development and Livelihood Program','info','program','1','/index.php?module=programs','1','2026-07-30 09:42:06');
INSERT INTO `notifications` VALUES ('29','6','New Leader Assignment','You have been assigned as Leader to Program: Agricultural Technology Transfer Program','info','program','3','/index.php?module=programs','0','2026-07-30 10:55:58');
INSERT INTO `notifications` VALUES ('30','3','New Member Assignment','You have been assigned as Member to Program: Agricultural Technology Transfer Program','info','program','3','/index.php?module=programs','1','2026-07-30 10:55:58');
INSERT INTO `notifications` VALUES ('31','3','New Leader Assignment','You have been assigned as Leader to Program: Agricultural Technology Transfer Program','info','program','3','/index.php?module=programs','1','2026-07-30 10:56:25');
INSERT INTO `notifications` VALUES ('32','3','New Member Assignment','You have been assigned as Member to Program: Agricultural Technology Transfer Program','info','program','3','/index.php?module=programs','1','2026-07-30 10:56:25');
INSERT INTO `notifications` VALUES ('33','2','New Leader Assignment','You have been assigned as Leader to Program: Community Development and Livelihood Program','info','program','1','/index.php?module=programs','0','2026-07-30 11:04:27');
INSERT INTO `notifications` VALUES ('34','3','Assignment Removed','You have been removed from Program: Community Development and Livelihood Program','warning','program','1','/index.php?module=programs','1','2026-07-30 11:04:27');
INSERT INTO `notifications` VALUES ('35','5','New Leader Assignment','You have been assigned as Leader to Project: Corn Production Technology Dissemination','info','project','4','/index.php?module=projects','0','2026-07-30 12:03:36');
INSERT INTO `notifications` VALUES ('36','3','New Member Assignment','You have been assigned as Member to Project: Corn Production Technology Dissemination','info','project','4','/index.php?module=projects','1','2026-07-30 12:03:36');
INSERT INTO `notifications` VALUES ('37','3','New Leader Assignment','You have been assigned as Leader to Project: Corn Production Technology Dissemination','info','project','4','/index.php?module=projects','1','2026-07-30 12:26:55');
INSERT INTO `notifications` VALUES ('38','3','New Member Assignment','You have been assigned as Member to Project: Corn Production Technology Dissemination','info','project','4','/index.php?module=projects','1','2026-07-30 12:26:55');
INSERT INTO `notifications` VALUES ('39','1','New Program Proposal','Faculty submitted a proposal: Test','info','proposal','7','/index.php?module=proposals','1','2026-07-30 12:49:55');
INSERT INTO `notifications` VALUES ('40','2','New Program Proposal','Faculty submitted a proposal: Test','info','proposal','7','/index.php?module=proposals','0','2026-07-30 12:49:55');
INSERT INTO `notifications` VALUES ('41','3','Proposal Approved','Your proposal \'Test\' has been approved.','success','proposal','7','/index.php?module=proposals','1','2026-07-30 12:57:43');
INSERT INTO `notifications` VALUES ('42','3','Proposal Approved','Your proposal \'Test\' has been approved.','success','proposal','7','/index.php?module=proposals','1','2026-07-30 13:02:55');
INSERT INTO `notifications` VALUES ('43','3','Proposal Approved','Your proposal \'Test\' has been approved.','success','proposal','7','/index.php?module=proposals','1','2026-07-30 13:12:33');
INSERT INTO `notifications` VALUES ('44','3','New Leader Assignment','You have been assigned as Leader to Project: Corn Production Technology Dissemination','info','project','4','/index.php?module=projects','0','2026-09-08 16:57:35');
INSERT INTO `notifications` VALUES ('45','5','New Member Assignment','You have been assigned as Member to Project: Corn Production Technology Dissemination','info','project','4','/index.php?module=projects','0','2026-09-08 16:57:35');
INSERT INTO `notifications` VALUES ('46','3','Proposal Returned','Your proposal \'Revised Proposal for Phase 2 Training\' has been returned.','warning','proposal','5','/index.php?module=proposals','0','2026-09-08 17:45:30');
CREATE TABLE `partner_agencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `agency_type` enum('government','ngo','private','academic') DEFAULT NULL,
  `contact_person` varchar(200) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `partner_agencies` VALUES ('1','Cauayan City Agriculture Office','government','Engr. Pedro Santos','09171234580','agriculture@cauayan.gov.ph','Cauayan City Hall, Isabela','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `partner_agencies` VALUES ('2','Department of Agriculture - Isabela','government','Dr. Maria Reyes','09171234581','da.isabela@gov.ph','Ilagan, Isabela','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `partner_agencies` VALUES ('3','Isabela Provincial Health Office','government','Dr. Jose Garcia','09171234582','health@isabela.gov.ph','Ilagan, Isabela','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `partner_agencies` VALUES ('4','Cauayan City Health Office','government','Dr. Linda Cruz','09171234583','health@cauayan.gov.ph','Cauayan City, Isabela','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `partner_agencies` VALUES ('5','Philippine Red Cross - Isabela Chapter','ngo','Roberto Bautista','09171234584','redcross@isabela.ph','Ilagan, Isabela','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `partner_agencies` VALUES ('6','Isabela State University - Echague','academic','Dr. Carmen Rivera','09171234585','echague@isu.edu.ph','Echague, Isabela','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `partner_agencies` VALUES ('7','Municipal Agriculture Office - Echague','government','Engr. Mark Tan','09171234586','agri@echague.gov.ph','Echague, Isabela','1','2026-07-29 17:25:11','2026-07-29 17:25:11');
CREATE TABLE `program_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `assignment_type` enum('leader','member') NOT NULL DEFAULT 'member',
  `assigned_by` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `prog_faculty` (`program_id`,`faculty_id`),
  KEY `fk_pa_prog` (`program_id`),
  KEY `fk_pa_faculty` (`faculty_id`),
  CONSTRAINT `fk_pa_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_profiles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pa_prog` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `program_assignments` VALUES ('1','1','2','leader','1','2026-07-29 17:25:11','1');
INSERT INTO `program_assignments` VALUES ('3','2','4','leader','1','2026-07-29 17:25:11','0');
INSERT INTO `program_assignments` VALUES ('5','3','5','member','1','2026-07-29 17:25:11','1');
INSERT INTO `program_assignments` VALUES ('7','2','1','member','1','2026-07-29 18:08:57','1');
INSERT INTO `program_assignments` VALUES ('9','2','2','leader','1','2026-07-29 18:09:16','1');
INSERT INTO `program_assignments` VALUES ('12','3','6','leader','1','2026-07-29 18:54:45','0');
INSERT INTO `program_assignments` VALUES ('16','1','3','member','1','2026-07-30 09:39:41','0');
INSERT INTO `program_assignments` VALUES ('21','3','3','leader','1','2026-07-30 10:55:58','1');
CREATE TABLE `programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_code` varchar(30) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `college` varchar(150) DEFAULT NULL,
  `campus` varchar(100) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('draft','active','completed','archived') NOT NULL DEFAULT 'draft',
  `objectives` text DEFAULT NULL,
  `expected_outputs` text DEFAULT NULL,
  `budget_allocation` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `program_code` (`program_code`),
  KEY `fk_prog_creator` (`created_by`),
  CONSTRAINT `fk_prog_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `programs` VALUES ('1','PROG-2026-0001','Community Development and Livelihood Program','A comprehensive program aimed at improving community livelihoods through skills training and technology transfer.','College of Agriculture','Cauayan Campus','2026-01-01','2028-12-31','active','To improve the quality of life of community members through sustainable livelihood programs and skills development.','Trained community members, improved livelihood skills, sustainable income-generating projects','500000.00','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `programs` VALUES ('2','PROG-2026-0002','Digital Literacy and ICT Skills Development','Program to enhance digital literacy among community members and faculty.','College of Computing and Information Sciences','Cauayan Campus','2026-02-01','2027-12-31','active','To bridge the digital divide by providing ICT skills training to community members.','Digitally literate community members, trained faculty, online learning resources','300000.00','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `programs` VALUES ('3','PROG-2026-0003','Agricultural Technology Transfer Program','Transfer of modern agricultural technologies to local farmers.','College of Agriculture','Cauayan Campus','2026-01-15','2027-06-30','active','To increase agricultural productivity through adoption of modern farming technologies.','Adopted technologies, increased crop yields, trained farmers','750000.00','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
CREATE TABLE `project_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `assignment_type` enum('leader','member') NOT NULL DEFAULT 'member',
  `assigned_by` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `proj_faculty` (`project_id`,`faculty_id`),
  KEY `fk_prja_proj` (`project_id`),
  KEY `fk_prja_faculty` (`faculty_id`),
  CONSTRAINT `fk_prja_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_profiles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_prja_proj` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `project_assignments` VALUES ('2','1','5','member','1','2026-07-29 17:25:11','0');
INSERT INTO `project_assignments` VALUES ('4','3','4','leader','1','2026-07-29 17:25:11','1');
INSERT INTO `project_assignments` VALUES ('5','4','5','leader','3','2026-07-29 17:25:11','1');
INSERT INTO `project_assignments` VALUES ('8','5','6','member','1','2026-07-29 17:25:11','0');
INSERT INTO `project_assignments` VALUES ('9','1','2','leader','1','2026-07-30 09:33:24','1');
INSERT INTO `project_assignments` VALUES ('10','2','2','leader','1','2026-07-30 09:33:36','1');
INSERT INTO `project_assignments` VALUES ('12','5','2','leader','1','2026-07-30 09:34:24','1');
INSERT INTO `project_assignments` VALUES ('14','4','3','leader','3','2026-07-30 12:03:36','1');
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_code` varchar(30) NOT NULL,
  `program_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `budget` decimal(15,2) NOT NULL DEFAULT 0.00,
  `funding_source_id` int(11) DEFAULT NULL,
  `partner_agency_id` int(11) DEFAULT NULL,
  `beneficiary_group_id` int(11) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `objectives` text DEFAULT NULL,
  `expected_outputs` text DEFAULT NULL,
  `status` enum('draft','pending','approved','ongoing','completed','cancelled','archived') NOT NULL DEFAULT 'draft',
  `completion_percentage` int(3) NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_code` (`project_code`),
  KEY `fk_proj_program` (`program_id`),
  KEY `fk_proj_funding` (`funding_source_id`),
  KEY `fk_proj_partner` (`partner_agency_id`),
  KEY `fk_proj_beneficiary` (`beneficiary_group_id`),
  KEY `fk_proj_creator` (`created_by`),
  CONSTRAINT `fk_proj_beneficiary` FOREIGN KEY (`beneficiary_group_id`) REFERENCES `beneficiary_groups` (`id`),
  CONSTRAINT `fk_proj_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_proj_funding` FOREIGN KEY (`funding_source_id`) REFERENCES `funding_sources` (`id`),
  CONSTRAINT `fk_proj_partner` FOREIGN KEY (`partner_agency_id`) REFERENCES `partner_agencies` (`id`),
  CONSTRAINT `fk_proj_program` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `projects` VALUES ('1','PROJ-2026-0001','1','Organic Farming Technology Transfer','Training program for organic farming techniques for local farmers in Cauayan City.','2026-01-15','2026-12-31','250000.00','1','1','1','Brgy. San Isidro, Cauayan City','To equip farmers with sustainable organic farming skills and knowledge.','Trained farmers, organic farming manual, demonstration farm','ongoing','45','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `projects` VALUES ('2','PROJ-2026-0002','1','Livelihood Skills Training: Bread and Pastry Making','Hands-on training for out-of-school youth on bread and pastry production.','2026-03-01','2026-08-31','120000.00','1',NULL,'3','ISU-Cauayan Campus','To provide practical skills for self-employment.','Trained youth, business plans, startup kits','ongoing','30','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `projects` VALUES ('3','PROJ-2026-0003','2','Digital Literacy Program for Senior Citizens','Workshop series teaching basic computer skills to senior citizens.','2026-02-01','2026-07-31','80000.00','5','4','2','Cauayan City Hall','To improve digital literacy among elderly residents.','Digitally literate seniors, training materials','ongoing','60','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `projects` VALUES ('4','PROJ-2026-0004','3','Corn Production Technology Dissemination','Technology transfer for improved corn production techniques.','2026-01-20','2026-12-31','350000.00','4','2','7','Minante, Cauayan City','To increase corn yield through modern production techniques.','Improved farming practices, higher yields, trained farmers','ongoing','50','1','2026-07-29 17:25:11','2026-07-30 13:35:04',NULL);
INSERT INTO `projects` VALUES ('5','PROJ-2025-0005','1','Community Health and Nutrition Awareness','Health education and nutrition counseling for community members.','2025-06-01','2025-12-31','95000.00','6','3',NULL,'District I, Cauayan City','To improve health awareness and nutrition practices.','Health awareness materials, trained health advocates','completed','100','1','2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
CREATE TABLE `proposal_approvals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proposal_id` int(11) NOT NULL,
  `approver_id` int(11) NOT NULL,
  `action` enum('submitted','reviewed','approved','returned','rejected') NOT NULL,
  `remarks` text DEFAULT NULL,
  `performed_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_pa_proposal` (`proposal_id`),
  CONSTRAINT `fk_pa_proposal` FOREIGN KEY (`proposal_id`) REFERENCES `proposals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `proposal_approvals` VALUES ('1','1','1','approved','Approved by ETS. Well-structured proposal.','2026-01-12 10:00:00');
INSERT INTO `proposal_approvals` VALUES ('2','2','1','approved','Approved with minor budget adjustments.','2026-02-17 14:00:00');
INSERT INTO `proposal_approvals` VALUES ('3','3','1','approved','Approved. Good community impact.','2026-01-22 09:00:00');
INSERT INTO `proposal_approvals` VALUES ('4','4','1','approved','Approved. Strong partnership with DA.','2026-01-27 11:00:00');
INSERT INTO `proposal_approvals` VALUES ('6','7','1','approved','','2026-07-30 13:02:55');
INSERT INTO `proposal_approvals` VALUES ('7','7','1','approved','','2026-07-30 13:12:33');
INSERT INTO `proposal_approvals` VALUES ('8','5','1','returned','test','2026-09-08 17:45:30');
CREATE TABLE `proposal_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proposal_id` int(11) NOT NULL,
  `version` int(11) NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `uploaded_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_pv_proposal` (`proposal_id`),
  CONSTRAINT `fk_pv_proposal` FOREIGN KEY (`proposal_id`) REFERENCES `proposals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE `proposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proposal_number` varchar(30) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `submitted_by` int(11) NOT NULL,
  `date_submitted` date DEFAULT NULL,
  `status` enum('draft','submitted','under_review','approved','returned','rejected') NOT NULL DEFAULT 'draft',
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `proposal_number` (`proposal_number`),
  KEY `fk_prop_project` (`project_id`),
  KEY `fk_prop_submitter` (`submitted_by`),
  CONSTRAINT `fk_prop_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_prop_submitter` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `proposals` VALUES ('1','PROP-2026-0001','1','Proposal for Organic Farming Technology Transfer','3','2026-01-10','approved',NULL,NULL,'Approved by ETS. Well-structured proposal.',NULL,'1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `proposals` VALUES ('2','PROP-2026-0002','2','Proposal for Livelihood Skills Training','3','2026-02-15','approved',NULL,NULL,'Approved with minor budget adjustments.',NULL,'1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `proposals` VALUES ('3','PROP-2026-0003','3','Proposal for Digital Literacy Program','4','2026-01-20','approved',NULL,NULL,'Approved. Good community impact.',NULL,'1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `proposals` VALUES ('4','PROP-2026-0004','4','Proposal for Corn Production Technology','5','2026-01-25','approved',NULL,NULL,'Approved. Strong partnership with DA.',NULL,'1','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `proposals` VALUES ('5','PROP-2026-0005','1','Revised Proposal for Phase 2 Training','3','2026-06-01','returned','1','2026-09-08 17:45:30','test',NULL,'2','2026-07-29 17:25:11','2026-09-08 17:45:30');
INSERT INTO `proposals` VALUES ('7','PROP-2026-0006',NULL,'Test','3','2026-07-30','approved','1','2026-07-30 13:12:33','',NULL,'1','2026-07-30 12:49:55','2026-07-30 13:12:33');
CREATE TABLE `report_approvals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(11) NOT NULL,
  `approver_id` int(11) NOT NULL,
  `action` enum('submitted','reviewed','approved','returned') NOT NULL,
  `remarks` text DEFAULT NULL,
  `performed_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ra_report` (`report_id`),
  CONSTRAINT `fk_ra_report` FOREIGN KEY (`report_id`) REFERENCES `accomplishment_reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `report_approvals` VALUES ('1','1','1','approved','Good progress. Continue with Q2 activities.','2026-04-08 10:00:00');
INSERT INTO `report_approvals` VALUES ('2','2','1','approved','Excellent work with the seniors program.','2026-04-05 14:00:00');
INSERT INTO `report_approvals` VALUES ('3','3','1','approved','Terminal report accepted. Well documented.','2026-01-18 09:00:00');
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_group` varchar(50) NOT NULL DEFAULT 'general',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `settings` VALUES ('1','school_name','Isabela State University - Cauayan','general','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `settings` VALUES ('2','school_address','Cauayan, Isabela, Philippines','general','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `settings` VALUES ('3','system_name','ETS Project Management Hub','general','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `settings` VALUES ('4','academic_year','2025-2026','general','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `settings` VALUES ('5','contact_email','ets@isu-cauayan.edu.ph','general','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `settings` VALUES ('6','contact_phone','+63 78 652 0000','general','2026-07-29 17:25:11','2026-07-29 17:25:11');
INSERT INTO `settings` VALUES ('7','website','https://isu.edu.ph','general','2026-07-29 17:25:11','2026-07-29 17:25:11');
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','faculty','viewer') NOT NULL DEFAULT 'faculty',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `users` VALUES ('1','admin','admin@isu-cauayan.edu.ph','$2y$12$9RyZgphPsFEARzNaZkT1o.vZBPubkt/10gwmH4n0MBp6rbm4KbVCu','admin','1','0','2026-09-08 17:49:17',NULL,'2026-07-29 17:25:11','2026-09-08 17:49:17',NULL);
INSERT INTO `users` VALUES ('2','etshead','ets.head@isu-cauayan.edu.ph','$2y$12$9RyZgphPsFEARzNaZkT1o.vZBPubkt/10gwmH4n0MBp6rbm4KbVCu','admin','1','0','2026-07-29 18:13:52',NULL,'2026-07-29 17:25:11','2026-07-29 18:13:52',NULL);
INSERT INTO `users` VALUES ('3','faculty1','juan.delacruz@isu-cauayan.edu.ph','$2y$12$9RyZgphPsFEARzNaZkT1o.vZBPubkt/10gwmH4n0MBp6rbm4KbVCu','faculty','1','0','2026-09-08 17:45:38',NULL,'2026-07-29 17:25:11','2026-09-08 17:45:38',NULL);
INSERT INTO `users` VALUES ('4','faculty2','maria.santos@isu-cauayan.edu.ph','$2y$12$9RyZgphPsFEARzNaZkT1o.vZBPubkt/10gwmH4n0MBp6rbm4KbVCu','faculty','1','0',NULL,NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `users` VALUES ('5','faculty3','pedro.reyes@isu-cauayan.edu.ph','$2y$12$9RyZgphPsFEARzNaZkT1o.vZBPubkt/10gwmH4n0MBp6rbm4KbVCu','faculty','1','0','2026-09-08 16:58:48',NULL,'2026-07-29 17:25:11','2026-09-08 16:58:48',NULL);
INSERT INTO `users` VALUES ('6','faculty4','ana.garcia@isu-cauayan.edu.ph','$2y$12$9RyZgphPsFEARzNaZkT1o.vZBPubkt/10gwmH4n0MBp6rbm4KbVCu','faculty','1','0',NULL,NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
INSERT INTO `users` VALUES ('7','viewer','dean@isu-cauayan.edu.ph','$2y$12$9RyZgphPsFEARzNaZkT1o.vZBPubkt/10gwmH4n0MBp6rbm4KbVCu','viewer','1','0',NULL,NULL,'2026-07-29 17:25:11','2026-07-29 17:25:11',NULL);
SET FOREIGN_KEY_CHECKS=1;
